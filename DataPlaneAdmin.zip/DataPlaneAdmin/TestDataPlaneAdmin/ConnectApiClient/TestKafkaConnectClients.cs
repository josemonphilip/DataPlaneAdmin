﻿using DataPlaneAdmin.ConnectApiClient;
using DataPlaneAdmin.ConnectApiClient.dto;
using DataPlaneAdmin.ConnectApiClient.Get;
using DataPlaneAdmin.ConnectApiClient.Model;
using DataPlaneAdmin.Models;
using DataPlaneAdmin.Services;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDataPlaneAdmin.ConnectApiClient
{
    [TestClass]
    public class TestKafkaConnectClients
    {
        [TestMethod]
        public async Task GetConnectors_ReturnsExpectedResultwithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>(/* dependencies */);
            var expectedConnectors = new List<string> { "connector1", "connector2" };
            mockClient.Setup(c => c.GetConnectors()).ReturnsAsync(expectedConnectors);

            // Act
            var result = await mockClient.Object.GetConnectors();

            // Assert
            CollectionAssert.AreEqual(expectedConnectors, result);
        }

        [TestMethod]
        public async Task GetConnector_ReturnsExpectedResultWithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>();
            var expectedConnector = new ConnectorDefinition { /* Set properties here */ };
            var connectorName = "testConnector";
            mockClient.Setup(c => c.getConnector(connectorName)).ReturnsAsync(expectedConnector);

            // Act
            var result = await mockClient.Object.getConnector(connectorName);

            // Assert
            Assert.AreEqual(expectedConnector, result);
        }

        [TestMethod]
        public async Task GetConnectorPlugins_ReturnsExpectedResultWithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>();
            var expectedPlugins = new List<ConnectorPlugin> { /* Set properties here */ };
            mockClient.Setup(c => c.getConnectorPlugins()).ReturnsAsync(expectedPlugins);

            // Act
            var result = await mockClient.Object.getConnectorPlugins();

            // Assert
            CollectionAssert.AreEqual(expectedPlugins, result);
        }
        [TestMethod]
        public async Task GetConnectorConfig_ReturnsExpectedResultWithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>();
            var expectedConfig = new Dictionary<string, string> { /* Set properties here */ };
            var connectorName = "testConnector";
            mockClient.Setup(c => c.getConnectorConfig(connectorName)).ReturnsAsync(expectedConfig);

            // Act
            var result = await mockClient.Object.getConnectorConfig(connectorName);

            // Assert
            CollectionAssert.AreEqual(expectedConfig, result);
        }

        [TestMethod]
        public async Task GetConnectorStatus_ReturnsExpectedResultWithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>();
            var expectedStatus = new ConnectorStatus { /* Set properties here */ };
            var connectorName = "testConnector";
            mockClient.Setup(c => c.getConnectorStatus(connectorName)).ReturnsAsync(expectedStatus);

            // Act
            var result = await mockClient.Object.getConnectorStatus(connectorName);

            // Assert
            Assert.AreEqual(expectedStatus, result);
        }

        [TestMethod]
        public async Task GetConnectorTasks_ReturnsExpectedResultWithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>();
            var expectedTasks = new List<ConnectorTask> { /* Set properties here */ };
            var connectorName = "testConnector";
            mockClient.Setup(c => c.getConnectorTasks(connectorName)).ReturnsAsync(expectedTasks);

            // Act
            var result = await mockClient.Object.getConnectorTasks(connectorName);

            // Assert
            CollectionAssert.AreEqual(expectedTasks, result.ToList());
        }

        [TestMethod]
        public async Task CreateConnector_ReturnsExpectedResultWithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>();
            var expectedConnectorDefinition = new ConnectorDefinition { /* Set properties here */ };
            var connectorDefinition = new CreateConnectorDefinition("test",new Dictionary<string, string>());
            mockClient.Setup(c => c.createConnector(connectorDefinition)).ReturnsAsync(expectedConnectorDefinition);

            // Act
            var result = await mockClient.Object.createConnector(connectorDefinition);

            // Assert
            Assert.AreEqual(expectedConnectorDefinition, result);
        }
        [TestMethod]
        public async Task RestartConnector_ReturnsExpectedResultWithMock()
        {
            // Arrange
            var mockClient = new Mock<IKafkaConnectClient>();
            var expectedRestartResult = new RestartResult { /* Set properties here */ };
            var connectorName = "testConnector";
            mockClient.Setup(c => c.restartConnector(connectorName)).ReturnsAsync(expectedRestartResult);

            // Act
            var result = await mockClient.Object.restartConnector(connectorName);

            // Assert
            Assert.AreEqual(expectedRestartResult, result);
        }







        [TestMethod]
        public async Task GetConnectors_ReturnsExpectedResult()
        {
            // Arrange
            var config = new Configuration
            {
                kafkaConnectApiConfiguration = new KafkaConnectApiConfiguration
                {
                    BaseUrl = "http://localhost",
                    Port = "8083"
                }
            };
            var client = new KafkaConnectClient(new HttpClient(), Options.Create(config));

            // Act
            var connectors = await client.GetConnectors();

            // Assert
            Assert.IsNotNull(connectors);
            Assert.IsTrue(connectors.Count > 0);
        }

        [TestMethod]
        public async Task getConnectorsWithInfoStatus()
        {
            // Arrange
            var config = new Configuration
            {
                kafkaConnectApiConfiguration = new KafkaConnectApiConfiguration
                {
                    BaseUrl = "http://localhost",
                    Port = "8084"
                }
            };
            var client = new KafkaConnectClient(new HttpClient(), Options.Create(config));

            // Act
            var connectors = await client.getConnectorsWithInfoStatus();

            // Assert
            Assert.IsNotNull(connectors);
            Assert.IsTrue(connectors.Count > 0);
        }
    }
}
