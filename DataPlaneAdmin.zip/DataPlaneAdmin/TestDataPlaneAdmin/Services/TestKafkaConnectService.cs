﻿using DataPlaneAdmin.ConnectApiClient.dto;
using DataPlaneAdmin.Models;
using DataPlaneAdmin.Services;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDataPlaneAdmin.Services
{
    [TestClass]
    public class TestKafkaConnectService
    {
        [TestMethod]
        public async Task GetConnectorsWithInfoStatusByClientId_ReturnsExpectedResult()
        {
            // Arrange
            var mockKafkaConnectClient = new Mock<IKafkaConnectClient>();
            var expectedConnectors = new Dictionary<string, ConnectorWithInfoStatus>  { /* Populate with test data */ };
            mockKafkaConnectClient.Setup(m => m.getConnectorsWithInfoStatus()).Returns(Task.FromResult(expectedConnectors as Dictionary<string, ConnectorWithInfoStatus>));

            var service = new KafkaConnectService(mockKafkaConnectClient.Object);

            // Act
            await service.GetConnectorsWithInfoStatus();

            // Assert
            mockKafkaConnectClient.Verify(m => m.getConnectorsWithInfoStatus(), Times.Once);
        }







  
    }
}
