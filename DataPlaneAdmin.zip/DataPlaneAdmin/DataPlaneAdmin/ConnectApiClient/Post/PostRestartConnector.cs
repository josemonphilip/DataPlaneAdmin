﻿using DataPlaneAdmin.ConnectApiClient.dto;

namespace DataPlaneAdmin.ConnectApiClient.Post
{
    public class PostRestartConnector : IPostRequest<RestartResult>
    {
        private readonly string connectorName;
        private Dictionary<string, bool> options = new Dictionary<string, bool>();

        public PostRestartConnector(string connectorName)
        {
            this.connectorName = connectorName ?? throw new ArgumentNullException(nameof(connectorName));
        }

        public PostRestartConnector WithIncludeTasks(bool includeTasks)
        {
            options["includeTasks"] = includeTasks;
            return this;
        }

        public PostRestartConnector WithOnlyFailed(bool onlyFailed)
        {
            options["onlyFailed"] = onlyFailed;
            return this;
        }

        public string GetApiEndpoint()
        {
            string url = "/connectors/" + Uri.EscapeDataString(connectorName) + "/restart";

            List<string> paramsList = new List<string>();
            foreach (KeyValuePair<string, bool> option in options)
            {
                if (option.Value != null)
                {
                    paramsList.Add(option.Key + "=" + (option.Value ? "true" : "false"));
                }
            }
            if (paramsList.Count > 0)
            {
                url = url + "?" + string.Join("&", paramsList);
            }
            return url;
        }

        public object GetRequestBody()
        {
            return "";
        }

        public RestartResult ParseResponse(string responseStr)
        {
            return  new RestartResult { Success=true } ;
        }

        public RequestMethod GetRequestMethod()
        {
            throw new NotImplementedException();
        }
    }
}
