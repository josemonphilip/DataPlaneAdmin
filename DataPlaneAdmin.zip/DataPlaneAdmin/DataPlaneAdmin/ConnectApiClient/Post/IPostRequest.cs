﻿namespace DataPlaneAdmin.ConnectApiClient.Post
{
    public interface IPostRequest<T> : IRequest<T>
    {
        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.POST;
        }
    }
}
