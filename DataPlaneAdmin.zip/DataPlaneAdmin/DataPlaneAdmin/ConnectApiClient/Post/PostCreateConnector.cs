﻿using DataPlaneAdmin.ConnectApiClient.dto;
using DataPlaneAdmin.ConnectApiClient.Model;
using Newtonsoft.Json;

namespace DataPlaneAdmin.ConnectApiClient.Post
{
    public class PostConnector : IPostRequest<ConnectorDefinition>
    {
        private readonly CreateConnectorDefinition connectorDefinition;

        public PostConnector(CreateConnectorDefinition connectorDefinition)
        {
            this.connectorDefinition = connectorDefinition ?? throw new ArgumentNullException(nameof(connectorDefinition));
        }

        public string GetApiEndpoint()
        {
            return "/connectors";
        }

        public object GetRequestBody()
        {
            return connectorDefinition;
        }

        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.POST; ;
        }

        public ConnectorDefinition ParseResponse(string responseStr)
        {
            try
            {
                return JsonConvert.DeserializeObject<ConnectorDefinition>(responseStr);
            }
            catch (JsonReaderException exception)
            {
                throw new Exception(exception.Message, exception);
            }
            catch (IOException exception)
            {
                throw new Exception(exception.Message, exception);
            }
        }
    }
}
