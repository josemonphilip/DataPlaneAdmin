﻿using DataPlaneAdmin.ConnectApiClient;
using DataPlaneAdmin.ConnectApiClient.dto;
using DataPlaneAdmin.ConnectApiClient.Model;

namespace DataPlaneAdmin.Services
{
    public interface IKafkaConnectClient
    {
        Task<List<string>> GetConnectors();
        Task<ConnectorDefinition> getConnector(String connectorName);
        Task<List<ConnectorPlugin>> getConnectorPlugins();
        Task<Dictionary<String, String>> getConnectorConfig(String connectorName);
        Task<ConnectorStatus> getConnectorStatus(String connectorName);
        Task<ICollection<ConnectorTask>> getConnectorTasks(String connectorName);
        Task<ConnectorDefinition> createConnector(CreateConnectorDefinition connectorDefinition);
        Task<RestartResult> restartConnector(String connectorName);
        Task<T> ExecuteRequest<T>(IRequest<T> request) where T : class;
        Task<Dictionary<string, ConnectorWithInfoStatus>> getConnectorsWithInfoStatus();
    }
}
