﻿using DataPlaneAdmin.ConnectApiClient.dto;
using DataPlaneAdmin.ConnectApiClient.Model;
using Newtonsoft.Json;

namespace DataPlaneAdmin.ConnectApiClient.Get
{
    public class GetConnectorWithInfoStatus : IGetRequest<Dictionary<string, ConnectorWithInfoStatus>>
    {
        public string GetApiEndpoint()
        {
            return "/connectors?expand=info&expand=status";
        }

        public object GetRequestBody()
        {
            throw new System.NotImplementedException();
        }

        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.GET;
        }

        public Dictionary<string, ConnectorWithInfoStatus> ParseResponse(string responseStr)
        {
            return JsonConvert.DeserializeObject< Dictionary<string, ConnectorWithInfoStatus>>(responseStr);
        }
    }
}
