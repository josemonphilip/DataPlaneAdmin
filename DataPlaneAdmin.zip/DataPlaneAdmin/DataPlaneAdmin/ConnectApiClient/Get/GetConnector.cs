﻿using DataPlaneAdmin.ConnectApiClient.Model;
using Newtonsoft.Json;
using System.Net;

namespace DataPlaneAdmin.ConnectApiClient.Get
{
    public class GetConnector : IGetRequest<ConnectorDefinition>
    {
        private readonly string connectorName;

        public GetConnector(string connectorName)
        {
            this.connectorName = connectorName ?? throw new ArgumentNullException(nameof(connectorName));
        }

        public string GetApiEndpoint()
        {
            return $"/connectors/{WebUtility.UrlEncode(connectorName)}";
        }

        public object GetRequestBody()
        {
            throw new NotImplementedException();
        }

        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.GET;
        }

        public ConnectorDefinition ParseResponse(string responseStr)
        {
            return JsonConvert.DeserializeObject<ConnectorDefinition>(responseStr);
        }
    }
}
