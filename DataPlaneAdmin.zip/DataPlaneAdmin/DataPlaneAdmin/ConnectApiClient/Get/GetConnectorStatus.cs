﻿using DataPlaneAdmin.ConnectApiClient.Model;
using Newtonsoft.Json;
using System.Net;

namespace DataPlaneAdmin.ConnectApiClient.Get
{
    public class GetConnectorStatus : IGetRequest<ConnectorStatus>
    {
        private readonly string connectorName;

        public GetConnectorStatus(string connectorName)
        {
            this.connectorName = connectorName ?? throw new ArgumentNullException(nameof(connectorName));
        }

        public string GetApiEndpoint()
        {
            return $"/connectors/{WebUtility.UrlEncode(connectorName)}/status";
        }

        public object GetRequestBody()
        {
            throw new NotImplementedException();
        }

        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.GET;
        }

        public ConnectorStatus ParseResponse(string responseStr)
        {
            return JsonConvert.DeserializeObject<ConnectorStatus>(responseStr);
        }
    }
}
