﻿using DataPlaneAdmin.ConnectApiClient.dto;
using Newtonsoft.Json;

namespace DataPlaneAdmin.ConnectApiClient.Get
{
    public class GetTasks : IGetRequest<ICollection<ConnectorTask>>
    {
        private readonly string connectorName;

        public GetTasks(string connectorName)
        {
            this.connectorName = connectorName ?? throw new ArgumentNullException(nameof(connectorName));
        }

        public string GetApiEndpoint()
        {
            return $"/connectors/{Uri.EscapeDataString(connectorName)}/tasks";
        }

        public object GetRequestBody()
        {
            throw new NotImplementedException();
        }

        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.GET;
        }

        public ICollection<Task> ParseResponse(string responseStr)
        {
            try
            {
                return JsonConvert.DeserializeObject<ICollection<Task>>(responseStr);
            }
            catch (JsonReaderException exception)
            {
                throw new Exception(exception.Message, exception);
            }
            catch (IOException exception)
            {
                throw new Exception(exception.Message, exception);
            }
        }

        ICollection<ConnectorTask> IRequest<ICollection<ConnectorTask>>.ParseResponse(string responseStr)
        {
            throw new NotImplementedException();
        }
    }
}
