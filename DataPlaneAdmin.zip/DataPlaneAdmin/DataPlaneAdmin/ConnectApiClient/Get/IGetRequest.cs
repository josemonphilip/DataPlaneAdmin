﻿namespace DataPlaneAdmin.ConnectApiClient.Get
{
    public interface IGetRequest<T> : IRequest<T>
    {
        // All GET requests use GET.
        RequestMethod GetRequestMethod()
        {
            return RequestMethod.GET;
        }

        // Not used in GET requests.
        
        object GetRequestBody()
        {
            return null;
        }
    }
}
