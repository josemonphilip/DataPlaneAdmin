﻿using Newtonsoft.Json;
using System.Net;

namespace DataPlaneAdmin.ConnectApiClient.Get
{
    public class GetConnectorConfig : IGetRequest<Dictionary<string, string>>
    {
        private readonly string connectorName;

        public GetConnectorConfig(string connectorName)
        {
            this.connectorName = connectorName ?? throw new ArgumentNullException(nameof(connectorName));
        }

        public string GetApiEndpoint()
        {
            return $"/connectors/{WebUtility.UrlEncode(connectorName)}/config";
        }

        public object GetRequestBody()
        {
            throw new NotImplementedException();
        }

        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.GET;
        }

        public Dictionary<string, string> ParseResponse(string responseStr)
        {
            return JsonConvert.DeserializeObject<Dictionary<string, string>>(responseStr);
        }
    }
}
