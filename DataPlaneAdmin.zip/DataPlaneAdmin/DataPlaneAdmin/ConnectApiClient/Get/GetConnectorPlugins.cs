﻿using DataPlaneAdmin.ConnectApiClient.Model;
using Newtonsoft.Json;

namespace DataPlaneAdmin.ConnectApiClient.Get
{
    public class GetConnectorPlugins : IGetRequest<List<ConnectorPlugin>>
    {
        public string GetApiEndpoint()
        {
            return "/connector-plugins";
        }

        public object GetRequestBody()
        {
            throw new NotImplementedException();
        }

        public RequestMethod GetRequestMethod()
        {
            return RequestMethod.GET;
        }

        public List<ConnectorPlugin> ParseResponse(string responseStr)
        {
            return JsonConvert.DeserializeObject<List<ConnectorPlugin>>(responseStr);
        }
    }
}
