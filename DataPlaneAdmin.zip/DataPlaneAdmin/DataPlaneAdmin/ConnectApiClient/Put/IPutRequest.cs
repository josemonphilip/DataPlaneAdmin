﻿namespace DataPlaneAdmin.ConnectApiClient.Put
{
    public interface IPutRequest<T> : IRequest<T>
    {
        RequestMethod GetRequestMethod()
        {
            return RequestMethod.PUT;
        }
    }
}
