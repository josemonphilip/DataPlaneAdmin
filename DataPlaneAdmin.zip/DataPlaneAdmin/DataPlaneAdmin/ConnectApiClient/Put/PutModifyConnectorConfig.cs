﻿namespace DataPlaneAdmin.ConnectApiClient.Put
{
    public class PutModifyConnectorConfig
    {
    }
}
