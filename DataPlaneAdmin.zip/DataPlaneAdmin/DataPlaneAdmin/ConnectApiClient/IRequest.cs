﻿namespace DataPlaneAdmin.ConnectApiClient
{

    public interface IRequest<T>
    {
        // The name of the API end point to issue a request against. This is appended to the API Hostname.
        string GetApiEndpoint();

        // Request Method, IE POST, GET, etc..
        RequestMethod GetRequestMethod();

        // Object to be submitted as the body of the request. It will be serialized to JSON using Newtonsoft.Json.
        object GetRequestBody();

        // Parse the rest service's response into a concrete object.
        T ParseResponse(string responseStr);
    }
    public enum RequestMethod
    {
        GET,
        POST,
        PUT,
        DELETE
        // Add other HTTP methods as needed
    }
}
