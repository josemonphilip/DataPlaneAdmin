﻿using DataPlaneAdmin.ConnectApiClient;
using DataPlaneAdmin.ConnectApiClient.dto;
using DataPlaneAdmin.ConnectApiClient.Get;
using DataPlaneAdmin.ConnectApiClient.Model;
using DataPlaneAdmin.ConnectApiClient.Post;
using DataPlaneAdmin.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace DataPlaneAdmin.Services
{
    public class KafkaConnectClient: IKafkaConnectClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;
        public KafkaConnectClient(HttpClient httpClient, IOptions<Configuration> configOptions)
        {
            _httpClient = httpClient;
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");

            //var kafkaConnectApiConfiguration = configOptions.Value.kafkaConnectApiConfiguration;
            var kafkaConnectApiConfiguration = configOptions.Value.kafkaConnectApiConfiguration;

            

            if (kafkaConnectApiConfiguration.BaseUrl == null)
            {
                throw new ArgumentNullException(nameof(kafkaConnectApiConfiguration.BaseUrl), "BaseUrl in KafkaConnectApiConfiguration is null");
            }

            // Normalize into "http://<hostname>" if not specified.
            if (kafkaConnectApiConfiguration.BaseUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                 kafkaConnectApiConfiguration.BaseUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                _baseUrl = kafkaConnectApiConfiguration.BaseUrl;
            }
            else
            {
                // Assume http protocol
                _baseUrl = "http://" + kafkaConnectApiConfiguration.BaseUrl;
            }

            // Append port if it exists
            if ( kafkaConnectApiConfiguration.Port != null)
            {
                _baseUrl += ":" + kafkaConnectApiConfiguration.Port;
            }
            _httpClient.BaseAddress = new Uri(_baseUrl);
        }

        /// <summary>
        /// Asynchronously retrieves a list of connectors.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of connector names.</returns>
        public async Task<List<string>>  GetConnectors()
        {
            return await ExecuteRequest(new GetConnectors());
        }

        /// <summary>
        /// Asynchronously retrieves the definition of a specific connector.
        /// </summary>
        /// <param name="connectorName">The name of the connector.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the definition of the connector.</returns>
        public async Task<ConnectorDefinition> getConnector(String connectorName)
        {
            return await ExecuteRequest(new GetConnector(connectorName));
        }

        /// <summary>
        /// Asynchronously retrieves a list of connector plugins.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of connector plugins.</returns>
        public async Task<List<ConnectorPlugin>> getConnectorPlugins()
        {
            return await ExecuteRequest(new GetConnectorPlugins());
        }
        /// <summary>
        /// Asynchronously retrieves the configuration of a specific connector.
        /// </summary>
        /// <param name="connectorName">The name of the connector.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the configuration of the connector.</returns>
        public async Task<Dictionary<String, String>> getConnectorConfig(String connectorName)
        {
            return await ExecuteRequest(new GetConnectorConfig(connectorName));
        }

        /// <summary>
        /// Asynchronously retrieves the status of a specific connector.
        /// </summary>
        /// <param name="connectorName">The name of the connector.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the status of the connector.</returns>
        public async Task<ConnectorStatus> getConnectorStatus(String connectorName)
        {
            return await ExecuteRequest(new GetConnectorStatus(connectorName));
        }

        /// <summary>
        /// Asynchronously retrieves the tasks of a specific connector.
        /// </summary>
        /// <param name="connectorName">The name of the connector.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains a collection of tasks for the connector.</returns>
        public async Task<ICollection<ConnectorTask>> getConnectorTasks(String connectorName)
        {
            return await ExecuteRequest(new GetTasks(connectorName));
        }
        /// <summary>
        /// Asynchronously retrieves a collection of connectors along with their information and status.
        /// </summary>
        /// <returns>
        /// A task that represents the asynchronous operation. 
        /// The task result contains a collection of connectors with their information and status.
        /// </returns>
        public async Task<Dictionary<string, ConnectorWithInfoStatus>> getConnectorsWithInfoStatus()
        {
            return await ExecuteRequest(new GetConnectorWithInfoStatus());
        }

        /// <summary>
        /// Asynchronously creates a new connector with the provided definition.
        /// </summary>
        /// <param name="connectorDefinition">The definition of the connector to be created.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the definition of the created connector.</returns>
        public async Task<ConnectorDefinition> createConnector(CreateConnectorDefinition connectorDefinition)
        {
            return await ExecuteRequest(new PostConnector(connectorDefinition));
        }

        /// <summary>
        /// Asynchronously restarts a specific connector.
        /// </summary>
        /// <param name="connectorName">The name of the connector to be restarted.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the result of the restart operation.</returns>
        public async Task<RestartResult> restartConnector(String connectorName)
        { 
             return await ExecuteRequest(new PostRestartConnector(connectorName));

        }



        public virtual async Task<T> ExecuteRequest<T>(IRequest<T> request) where T : class
        {
            var url = request.GetApiEndpoint();

            try
            {
                switch (request.GetRequestMethod())
                {
                    case RequestMethod.GET:
                        return await SubmitGetRequest<T>(url, new Dictionary<string, string>());
                    case RequestMethod.POST:
                        return (T)await SubmitPostRequest(url, request.GetRequestBody());
                    case RequestMethod.PUT:
                        return (T)await SubmitPutRequest(url, request.GetRequestBody());
                    case RequestMethod.DELETE:
                        await SubmitDeleteRequest(url);
                        return null;
                    default:
                        throw new ArgumentException("Unknown Request Method: " + request.GetRequestMethod());
                }
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception);
            }
        }

       

        private async Task<T> SubmitGetRequest<T>(string endpoint, Dictionary<string, string> getParams)
        {
            var uriBuilder = new UriBuilder(_baseUrl + endpoint);
            var query = HttpUtility.ParseQueryString(uriBuilder.Query);

            foreach (var param in getParams)
            {
                query[param.Key] = param.Value;
            }

            uriBuilder.Query = query.ToString();
            string urlWithParams = uriBuilder.ToString();
            HttpResponseMessage? response = null;
            try
            {
                response = await _httpClient.GetAsync(urlWithParams);
               
            }


            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
               // return content == null ? default : JsonConvert.DeserializeObject<T>(content);
               return default;
            }
            else
            {
                throw new HttpRequestException($"GET request failed with status code: {response.StatusCode}");
            }
        }

        private async Task<T> SubmitPostRequest<T>(string endpoint, T data)
        {
            var content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync(_baseUrl + endpoint, content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(responseContent);
            }
            else
            {
                throw new HttpRequestException($"POST request failed with status code: {response.StatusCode}");
            }
        }

        private async Task<T> SubmitPutRequest<T>(string endpoint, T data)
        {
            var content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync(_baseUrl + endpoint, content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(responseContent);
            }
            else
            {
                throw new HttpRequestException($"PUT request failed with status code: {response.StatusCode}");
            }
        }

        private async Task SubmitDeleteRequest(string endpoint)
        {
            var response = await _httpClient.DeleteAsync(_baseUrl + endpoint);

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"DELETE request failed with status code: {response.StatusCode}");
            }
        }

        
    }
}
