﻿namespace DataPlaneAdmin.ConnectApiClient.dto
{
    public class RestartResult
    {
        public bool Success { get; set; }
    }
}
