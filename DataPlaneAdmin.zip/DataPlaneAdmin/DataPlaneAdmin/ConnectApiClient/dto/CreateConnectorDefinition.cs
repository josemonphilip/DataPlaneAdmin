﻿namespace DataPlaneAdmin.ConnectApiClient.dto
{
    public class CreateConnectorDefinition
    {

        public string Name { get; private set; }
        public Dictionary<string, string> Config { get; private set; }

        public CreateConnectorDefinition(string name, Dictionary<string, string> config)
        {
            Name = name;
            Config = new Dictionary<string, string>(config);
        }

        public override string ToString()
        {
            return $"CreateConnectorDefinition{{name='{Name}', config={Config}}}";
        }

        public class Builder
        {
            private string name;
            private Dictionary<string, string> config = new Dictionary<string, string>();

            public Builder WithName(string name)
            {
                this.name = name;
                return this;
            }

            public Builder WithConfig(Dictionary<string, string> config)
            {
                this.config = new Dictionary<string, string>(config);
                return this;
            }

            public Builder WithConfig(string key, string value)
            {
                this.config[key] = value;
                return this;
            }

            public Builder WithConfig(string key, object value)
            {
                this.config[key] = value.ToString();
                return this;
            }

            public CreateConnectorDefinition Build()
            {
                return new CreateConnectorDefinition(name, config);
            }
        }

        public static Builder NewBuilder()
        {
            return new Builder();
        }
    }
}
