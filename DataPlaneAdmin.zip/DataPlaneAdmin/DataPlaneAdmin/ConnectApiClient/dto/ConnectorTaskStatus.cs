﻿namespace DataPlaneAdmin.ConnectApiClient.dto
{
    public class ConnectorTaskStatus
    {
        public int Id { get; set; } = -1;
        public string State { get; set; }
        public string Trace { get; set; }
        public string WorkerId { get; set; }

        public ConnectorTaskStatus() { }

        public ConnectorTaskStatus(int id, string state, string trace, string workerId)
        {
            Id = id;
            State = state;
            Trace = trace;
            WorkerId = workerId;
        }

        public override string ToString()
        {
            return $"TaskStatus{{id={Id}, state='{State}', trace='{Trace}', workerId='{WorkerId}'}}";
        }
    }
}
