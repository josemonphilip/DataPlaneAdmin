﻿using System.Threading.Tasks;

namespace DataPlaneAdmin.ConnectApiClient.dto
{
    public class ConnectorTask
    {
        public TaskId Id { get; set; }
        public Dictionary<string, string> Config { get; set; }
        public ConnectorTask() { }

        public ConnectorTask(TaskId id, Dictionary<string, string> config)
        {
            Id = id;
            Config = new Dictionary<string, string>(config);
        }

        public override string ToString()
        {
            return $"Task{{id={Id}, config={Config}}}";
        }
    }
    public class TaskId
    {
        public string Connector { get; set; }
        public int Task { get; set; }

        public TaskId() { }

        public TaskId(string connector, int task)
        {
            Connector = connector;
            Task = task;
        }

        public override string ToString()
        {
            return $"TaskId{{connector='{Connector}', task={Task}}}";
        }
    }
}
