﻿namespace DataPlaneAdmin.ConnectApiClient.Model
{
    public class ConnectorStatus
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public Dictionary<string, string> Connector { get; set; }
        public List<TaskStatus> Tasks { get; set; }

        public ConnectorStatus() { }

        public ConnectorStatus(string name, string type, Dictionary<string, string> connector, List<TaskStatus> tasks)
        {
            Name = name;
            Type = type;
            Connector = new Dictionary<string, string>(connector);
            Tasks = new List<TaskStatus>(tasks);
        }

        public override string ToString()
        {
            return $"ConnectorStatus{{name='{Name}', connector={Connector}, tasks={Tasks}, type={Type}}}";
        }
    }

    public class TaskStatus
    {
        public string Id { get; set; }
        public string State { get; set; }
        public string WorkerId { get; set; }

        public TaskStatus() { }

        public TaskStatus(string id, string state, string workerId)
        {
            Id = id;
            State = state;
            WorkerId = workerId;
        }

        public override string ToString()
        {
            return $"TaskStatus{{id='{Id}', state='{State}', workerId='{WorkerId}'}}";
               }
    }
    }

