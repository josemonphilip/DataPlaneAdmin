﻿using ksqlDB.RestApi.Client.KSql.RestApi.Responses.Connectors;

namespace DataPlaneAdmin.ConnectApiClient.dto
{
    public class ConnectorWithInfoStatus
    {
        public Info info { get; set; }
        public Status status { get; set; }
    }

    public class Info
    {
        public string name { get; set; }
        public Dictionary<string, string> config { get; set; }
//        public List<Task> tasks { get; set; }
        public string type { get; set; }
    }

    public class Status
    {
        public string name { get; set; }
        public Connector connector { get; set; }
        public List<TaskStatus> tasks { get; set; }
        public string type { get; set; }
    }

    public class Connector
    {
        public string state { get; set; }
        public string worker_id { get; set; }
    }
    public class TaskStatus
    {
        public int id { get; set; }
        public string state { get; set; }
        public string worker_id { get; set; }
    }
}
