﻿namespace DataPlaneAdmin.ConnectApiClient.dto
{
    public class RestResponse
    {
        private readonly string responseStr;
        private readonly int httpCode;

        public RestResponse(string responseStr, int httpCode)
        {
            this.responseStr = responseStr;
            this.httpCode = httpCode;
        }

        public string GetResponseStr()
        {
            return responseStr;
        }

        public int GetHttpCode()
        {
            return httpCode;
        }

        public override string ToString()
        {
            return $"RestResponse{{responseStr='{responseStr}', httpCode={httpCode}}}";
        }
    }
}
