﻿using Newtonsoft.Json;

namespace DataPlaneAdmin.ConnectApiClient.Model
{
    public class ConnectorPlugin
    {
        [JsonProperty("class")]
        public string ClassName { get; set; }
        public string Type { get; set; }
        public string Version { get; set; }

        public ConnectorPlugin() { }

        public ConnectorPlugin(string className, string type, string version)
        {
            ClassName = className;
            Type = type;
            Version = version;
        }

        public override string ToString()
        {
            return $"ConnectorPlugin{{className='{ClassName}', type='{Type}', version='{Version}'}}";
        }
    }
}
