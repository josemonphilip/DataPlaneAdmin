﻿namespace DataPlaneAdmin.ConnectApiClient.Model
{
    public class ConnectorDefinition
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public Dictionary<string, string> Config { get; set; }
        public List<TaskDefinition> Tasks { get; set; }

        public ConnectorDefinition()
        {
            Config = new Dictionary<string, string>();
            Tasks = new List<TaskDefinition>();
        }

        public ConnectorDefinition(string name, string type, Dictionary<string, string> config, List<TaskDefinition> tasks)
        {
            Name = name;
            Type = type;
            Config = new Dictionary<string, string>(config);
            Tasks = new List<TaskDefinition>(tasks);
        }

        public override string ToString()
        {
            return $"ConnectorDefinition{{name='{Name}', type='{Type}', config={Config}, tasks={Tasks}}}";
        }
    }

    public class TaskDefinition
    {
        public string Connector { get; set; }
        public int Task { get; set; }

        public TaskDefinition() { }

        public TaskDefinition(string connector, int task)
        {
            Connector = connector;
            Task = task;
        }

        public override string ToString()
        {
            return $"TaskDefinition{{connector='{Connector}', task={Task}}}";
        }
    }
}
