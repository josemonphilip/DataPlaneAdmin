﻿using DataPlaneAdmin.Models;

namespace DataPlaneAdmin.Services
{
    public interface IKafkaConnectService
    {
        Task<List<ConnectorFull>> GetConnectorsWithInfoStatus();
    }
}
