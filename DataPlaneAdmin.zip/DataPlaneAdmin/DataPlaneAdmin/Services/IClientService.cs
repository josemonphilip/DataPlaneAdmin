﻿using DataPlaneAdmin.Models;

namespace DataPlaneAdmin.Services
{
    public interface IClientService
    {
        Task<Client> GetClientById(int id);
    }
}
