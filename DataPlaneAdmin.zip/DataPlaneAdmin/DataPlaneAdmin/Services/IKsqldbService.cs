﻿namespace DataPlaneAdmin.Services
{
    public interface IKsqldbService
    {
    }
}
