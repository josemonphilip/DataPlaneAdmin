﻿using DataPlaneAdmin.Models;

namespace DataPlaneAdmin.Services
{
    public class ClientService:IClientService
    {
        IKafkaConnectService _kafkaConnectService;
        public ClientService(IKafkaConnectService kafkaConnectService)
        {

            _kafkaConnectService = kafkaConnectService;

        }

        public async Task<Client> GetClientById(int id)
        {
            Client client = new Client();

            //query client table in ksqldb

            //check connectors installed for this client

            //get activated pipelines for this client
           var connectordet= await _kafkaConnectService.GetConnectorsWithInfoStatus();
            client.Connectors = connectordet.Where(c => c.ClientId == id).ToList();
            return client;
        }
    }
}
