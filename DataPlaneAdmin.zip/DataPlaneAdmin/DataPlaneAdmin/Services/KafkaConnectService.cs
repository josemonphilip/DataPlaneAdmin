﻿using DataPlaneAdmin.ConnectApiClient.dto;
using DataPlaneAdmin.Models;
using System.ComponentModel;

namespace DataPlaneAdmin.Services
{
    public class KafkaConnectService: IKafkaConnectService
    {
        private IKafkaConnectClient _kafkaConnectClient;
        public KafkaConnectService(IKafkaConnectClient kafkaConnectClient)
        {
            this._kafkaConnectClient = kafkaConnectClient;      
        }
        public async Task<List<ConnectorFull>> GetConnectorsWithInfoStatus()
        {
           var connectInfo= await _kafkaConnectClient.getConnectorsWithInfoStatus();
            var connectors = new List<ConnectorFull>();
            foreach (var connector in connectInfo)
            {
                var clientIdString = connector.Value.info.config.FirstOrDefault(i => i.Key.Equals("yourKey")).Value;
                int clientId;
                if (!int.TryParse(clientIdString, out clientId))  clientId = 0;
                
                var _connector = new ConnectorFull
                {
                    ConnectorName = connector.Key,
                    ConnectorType = connector.Value.info.type,
                    ConnectorStatus = connector.Value.status.connector.state,
                    ClientId = clientId,
                    ConnectorConfig = connector.Value.info.config
                };
                connectors.Add(_connector);

           }
            return connectors;
        }

    }
}
