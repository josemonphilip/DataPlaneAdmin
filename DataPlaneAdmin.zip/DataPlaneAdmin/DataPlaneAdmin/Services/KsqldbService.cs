﻿namespace DataPlaneAdmin.Services
{
    public class KsqldbService
    {
    }
}
