﻿namespace DataPlaneAdmin.Models
{
    public class Client
    {
        public int ClientID { get; set; }
        public String ClientName { get; set; }
        public string ClientAddress { get; set; }
        public string ClientPhone { get; set; }
        public string CleintEmail { get; set; }
        public List<ConnectorFull> Connectors { get; set; }
    }


}
