﻿namespace DataPlaneAdmin.Models
{


    public class Configuration
    {
        public KafkaConnectApiConfiguration kafkaConnectApiConfiguration { get; set; }
        public KSQLDBApiConfiguration kSQLDBApiConfiguration{ get; set; }
    }






    public class KSQLDBApiConfiguration
    {
        public string BaseUrl { get; set; }
        public string Port { get; set; }
    }

    public class KafkaConnectApiConfiguration
    {
        public string BaseUrl { get; set; }
        public string Port { get; set; }
    }
}
