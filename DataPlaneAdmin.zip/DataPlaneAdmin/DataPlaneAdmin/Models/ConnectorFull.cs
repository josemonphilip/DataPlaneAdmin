﻿namespace DataPlaneAdmin.Models
{
    public class ConnectorFull
    {
        public string ConnectorName { get; set; }
        public string ConnectorType { get; set; }
        public string ConnectorStatus { get; set; }
        public Dictionary<string,String> ConnectorConfig { get; set; }
        public int ClientId { get; set; }
    }
}
