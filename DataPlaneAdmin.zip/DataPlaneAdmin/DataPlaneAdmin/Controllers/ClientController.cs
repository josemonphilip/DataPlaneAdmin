﻿using DataPlaneAdmin.Models;
using DataPlaneAdmin.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DataPlaneAdmin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private IClientService _clientService;
        public ClientController(IClientService clientService)
        {
            _clientService = clientService;
        }

        // GET: api/Client
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Get all clients");
        }

        // GET: api/Client/5
        [HttpGet("{id}", Name = "Get")]
        public IActionResult Get(int id)
        {
           var client= _clientService.GetClientById(id);
            return Ok(client);
        }

        // POST: api/Client
        [HttpPost]
        public IActionResult Post([FromBody] string value)
        {
            return Ok("Create a new client");
        }

        // PUT: api/Client/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] string value)
        {
            return Ok("Update client by id");
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok("Delete client by id");
        }
    }
}
